"""
Version: 2024.03.30
Author: ThreadsPoster Team
Description: ThreadsPoster 套件初始化模組，定義套件版本和基本資訊
Last Modified: 2024.03.30
Changes:
- 更新版本號
- 優化套件結構
- 改進套件說明
- 加強版本控制
"""

"""
Threads Bot - 自動回覆系統
"""

__version__ = '0.1.0' 